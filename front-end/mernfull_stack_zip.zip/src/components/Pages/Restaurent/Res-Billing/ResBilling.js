import React from 'react'
import './ResBilling.css'

const ResBilling = () => {
  return (
    <>
    
    <center>
    <h1 style={{marginTop:"100px"}}> Restaurent Billing Page</h1>
</center>
    </>
  )
}

export default ResBilling
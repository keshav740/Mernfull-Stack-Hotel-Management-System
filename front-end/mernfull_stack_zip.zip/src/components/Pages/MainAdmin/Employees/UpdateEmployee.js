import React from 'react'

const UpdateEmployee = () => {
  return (
    <div>UpdateEmployee</div>
  )
}

export default UpdateEmployee